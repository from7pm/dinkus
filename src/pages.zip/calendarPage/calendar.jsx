import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import './Calendar.css';

function Calendar() {

    const navigate = useNavigate();

    const home = () =>
        navigate(`/home`);

    const [active, setActive] = useState(null);

    const today = new Date();

    const [day, setDay] = useState(today.getDate());
    const [month, setMonth] = useState(today.getMonth() + 1);
    const [year, setYear] = useState(today.getFullYear());

    const getWeekday = () =>
        new Date().toLocaleDateString("ko-KR", {
            weekday: "long",
        });

    const [weekdays, setWeekdays] = useState(getWeekday());

    const getFormattedTime = () => {
        const now = new Date();
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        return `${hours}:${minutes}`;
    };

    const [currentTime, setCurrentTime] = useState(getFormattedTime());

    useEffect(() => {
        const timer = setInterval(() => {

            setCurrentTime(getFormattedTime());
        }, 1000);

        return () => clearInterval(timer);
    }, []);

    return (

        <>

            <div className="calendar-container">
                <div className="calendar-logo-container">
                    <img className="calendar-home"
                        src="../../../home.svg"
                        onClick={home}
                        alt="home button"
                    />
                    <img className="calendar-logo"
                        src="../../../dinkus.svg"
                        alt="dinkus" />
                    <div className="calendar-subtitle">
                        <p>calendar</p>
                    </div>
                </div>
                <div className="papers-container">
                    <div className="clip-container">
                        <img className="clip"
                            src="../../../clip.svg"
                            alt="clip"
                        />
                    </div>
                    <div className="content-container">
                        <div className="">{year}년 {month}월 {day}일 {weekdays}</div>
                        <p>{currentTime}</p>
                        <p></p>
                    </div>
                </div>
            </div>
        </>
    );

}

export default Calendar;