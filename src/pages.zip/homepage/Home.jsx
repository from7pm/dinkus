import { useNavigate } from 'react-router-dom';
import './home.css';

function Home() {

    const navigate = useNavigate();

    const scriptTime = () =>
        navigate(`/script`)

    const diaries = () =>
        navigate(`/diaries`)

    const calendar = () =>
        navigate(`/calendar`)

    const setting = () =>
        navigate(`/setting`)

    const years = new Date();
    const year = String(years.getFullYear());

    const nlcalendar = ["CALENDAR"];

    return (
        <>

            <div className="homepage-container">
                <div className="setting">
                    <img className="home-setting-button"
                        src="../../../setting.svg"
                        onClick={setting}
                        alt="settings" />
                </div>
                <div className="homepage-logo-container">
                    <img className="home-button"
                        src="../../../home.svg"
                        alt="home button"
                    />
                    <img className="home-logo"
                        src="../../../dinkus.svg"
                        alt="dinkus"
                    />
                    <div className="home-subtitle">
                        <p>HOME</p>
                    </div>
                </div>
                <div className="bookshelf-container">
                    <div className="content-container">
                        <div className="first-corner">
                            <div className="script-time"
                                onClick={scriptTime}
                            >
                                <div className="script-s">
                                    <span>S</span>
                                </div>
                                <div className="script-c">
                                    <span>C</span>
                                </div>
                                <div className="script-ri">
                                    <span>R</span>&nbsp;&nbsp;<span>I</span>
                                </div>
                                <div className="script-pt">
                                    <span>P</span>&nbsp;<span>T</span>
                                </div>
                                <div className="time-t">
                                    <span>T</span>
                                </div>
                                <div className="time-i">
                                    <span>I</span>
                                </div>
                                <div className="time-m">
                                    <span>M</span>
                                </div>
                                <div className="time-e">
                                    <span>E</span>
                                </div>
                            </div>
                        </div>
                        <div className="second-corner">
                            <div className="diaries"
                                onClick={diaries}>
                                <div className="dia">
                                    <div className="diaries-dia-up">
                                        &nbsp;
                                    </div>
                                    <div className="diaries-dia">
                                        <span>D</span>&nbsp;&nbsp;<span>
                                            I</span>&nbsp;&nbsp;<span>A</span>
                                    </div>
                                    <div className="diaries-dia-down">
                                        &nbsp;
                                    </div>
                                </div>
                                <div className="diaries-ries-r">
                                    <span>R</span>
                                </div>
                                <div className="diaries-ries-i">
                                    <span>I</span>
                                </div>
                                <div className="diaries-ries-e">
                                    <span>E</span>
                                </div>
                                <div className="diaries-ries-s">
                                    <span>S</span>
                                </div>
                            </div>
                        </div>
                        <div className="third-section">
                            <div className="calendar-corner">
                                <span className="calendar-year" onClick={calendar}>
                                    <ul>
                                        <li>{year}</li>
                                        <li>{nlcalendar}</li>
                                    </ul>
                                </span>
                                <img className="calendar"
                                    src="../../../calendar.svg"
                                    onClick={calendar}
                                    alt="calendar year"
                                />
                            </div>
                        </div>
                        <div className="fourth-corner">
                            <div className="my-account-and-favorites">
                                <img className="my-account-img"
                                    src="../../../star.svg"
                                    alt="my account" />
                                <img className="favorites-img"
                                    src="../../../heart.svg"
                                    alt="favorites" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )

}

export default Home;

//아직 완성된 필사집이 없어요.
//필사 10편을 모으면 첫 번째 책이 꽂혀요.