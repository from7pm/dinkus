import { useNavigate } from 'react-router-dom';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { arrayPoems } from './arrayPoems.js';
import './Script.css';

function Script() {

    const navigate = useNavigate();
    const textareaRef = useRef();

    const home = () =>
        navigate(`/home`)

    const [selectedTitle, setSelectedTitle] = useState("");

    const [page, setPage] = useState(0);

    useEffect(() => {
        const currentPage = setPage ? { up } || { down } : '';

        if (!currentPage) return;
        if (selectedTitle !== 0) return;

        setPage();

    });

    const titles = useMemo(() => Object.keys(arrayPoems ?? {}), [arrayPoems]);

    const current = useMemo(() => {
        const currentArr = arrayPoems?.[titles[page]] ?? [];
        return currentArr.map((phrase, idx) => ({ phrase, key: idx }));
    }, [arrayPoems, titles, page]);

    const maxPage = 100; //maxPage 찰 때마다 메인에 책 한 권씩 추가하기... 메인에 최대 몇 권 차게 할 것인지 생각하기...

    function up() { setPage(p => Math.min(maxPage, p + 1)) };
    function down() { setPage(p => Math.max(0, p - 1)) };

    // 처음 화면 들어올 때 상세설명 페이지 뜨게! 다시는 보지 않기 버튼도 넣고..

    const focusAtEnd = () => {
        const textarea = textareaRef.current;
        if (!textarea) return;

        textarea.focus();

        const end = textarea.value.length;
        textarea.setSelectionRange(end, end);
    };

    return (
        <>

            <div className="script-container">
                <div className="setting">
                    <img className="script-setting-button"
                        src="../../../setting.svg"
                        alt="settings" />
                </div>
                <div className="script-logo-container">
                    <img className="script-home"
                        src="../../../home.svg"
                        onClick={home}
                        alt="home button"
                    />
                    <img className="script-logo"
                        src="../../../dinkus.svg"
                        onClick={home}
                        alt="dinkus" />
                    <div className="script-subtitle">
                        <p>SCRIPT TIME</p>
                    </div>
                </div>
                <div className="papers-container">
                    <div className="clip-container">
                        <img className="clip"
                            src="../../../clip.svg"
                            alt="clip"
                        />
                    </div>
                    <div className="content-change-button">
                        <div className="up-button-container">
                            <img className="up-button-img"
                                src="../../../up.svg"
                                alt="up button"
                                onClick={() => up()}
                            />
                        </div>
                        <div className="down-button-container">
                            <img className="down-button-img"
                                src="../../../down.svg"
                                alt="down button"
                                onClick={() => down()}
                            />
                        </div>
                    </div>
                    <div className="content-container">
                        <div className="lines-square">

                            {current.map(({ phrase, key }) => {

                                const chars = Array.from(phrase);

                                return (
                                    <div className="word-line-out-box" key={key}>
                                        {chars.map((ch, i) => (
                                            <div className="word-line-box">
                                                <div className="word-box" key={i}>
                                                    {ch}
                                                </div>
                                            </div>
                                        ))}

                                    </div>
                                );

                            })}
                        </div>
                    </div>
                </div>
            </div>
        </>
    )

}

export default Script;