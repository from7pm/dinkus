import { useNavigate } from 'react-router-dom';
import './Diaries.css';
import { useEffect, useState } from 'react';

function Diaries() {

    const navigate = useNavigate();

    const home = () =>
        navigate(`/home`)

    const today = new Date();

    const [day, setDay] = useState(today.getDate());
    const [month, setMonth] = useState(today.getMonth() + 1);
    const [year, setYear] = useState(today.getFullYear());

    const getWeekday = () =>
        new Date().toLocaleDateString("ko-KR", {
            weekday: "long",
        });

    const [weekdays, setWeekdays] = useState(getWeekday());

    const getFormattedTime = () => {
        const now = new Date();
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        return `${hours}:${minutes}`;
    };

    const [currentTime, setCurrentTime] = useState(getFormattedTime());

    useEffect(() => {
        const timer = setInterval(() => {

            setCurrentTime(getFormattedTime());
        }, 1000);

        return () => clearInterval(timer);
    }, []);

    return (
        <>

            <div className="diaries-container">
                <div className="diaries-logo-container">
                    <img className="diaries-home"
                        src="../../../home.svg"
                        onClick={home}
                        alt="home button"
                    />
                    <img className="diaries-logo"
                        src="../../../dinkus.svg"
                        alt="dinkus" />
                    <div className="diaries-subtitle">
                        <p>DIARIES</p>
                    </div>
                </div>
                <div className="diaries-papers-container">
                    <div className="diaries-clip-container">
                        <img className="diaries-clip"
                            src="../../../clip.svg"
                            alt="clip"
                        />
                    </div>
                    <div className="diaries-content-container">
                        <div className="">{year}년 {month}월 {day}일 {weekdays}</div>
                        <p>{currentTime}</p>
                        <p></p>
                    </div>
                </div>
            </div>
        </>
    )

}

export default Diaries;